# Current App State

<!-- gpt-starter:gicleeapp-push:start -->
GicleeApp Studio v1.41.2

GitHub / aktualna wersja aplikacji (`eagleblastmusic-lgtm/gicleeapp`):
v1.41.2 — zgodnie z `cursor-api/giclee_app/__init__.py` i `cursor-api/package.json`
Ostatni push GicleeApp: `8a3c60a` na `main` (2026-07-07 22:19 UTC) — Refresh GicleeApp repository snapshot

Monorepo origin/master (projekt / docs):
845191c docs(gpt): refresh starter files after GICLÉE FRAME F2.1

Lokalne commity monorepo (nie na origin/master, push pending):
- `c966912` feat(perf-agent): add guided performance audit workflow
- `926bc60` perf(studio): improve cold perceived readiness across dashboard, katalog and gicleeframe

Previous checkpoint:
46fc718 feat(studio): add GICLÉE FRAME page inventory RAM editor (v1.40.0)

Branch status:
- **GitHub gicleeapp:** v1.41.2 / `main` @ `8a3c60a` (auto-sync po Push GicleeApp, 2026-07-07 22:19 UTC)
- **monorepo origin/master:** `845191c` — docs(gpt): refresh starter files after GICLÉE FRAME F2.1
- **lokalnie monorepo:** dodatkowe commity względem origin/master — push pending (nie zakładać push monorepo bez potwierdzenia użytkownika)
  - `c966912` feat(perf-agent): add guided performance audit workflow
  - `926bc60` perf(studio): improve cold perceived readiness across dashboard, katalog and gicleeframe

GPT starter files:
auto-sync po Push GicleeApp 2026-07-07 22:19 UTC (gicleeapp `8a3c60a`, v1.41.2; paczka v37; źródło = ten folder, nie ZIP)

Recent context:
- **GitHub gicleeapp:** v1.41.2 / `main` @ `8a3c60a` — auto-sync po Push GicleeApp
- GICLÉE FRAME™ F2.1: closed + pushed (historycznie v1.40.1 / `4647c1b`; aktualna wersja aplikacji na GitHub jest nowsza)
- **Performance Agent** — lokalny commit monorepo `c966912`; push monorepo pending (nie mylić z pushem gicleeapp)
- Local runtime/untracked still outside commit and remote (working tree hygiene pending)
<!-- gpt-starter:gicleeapp-push:end -->

Completed:
- Background Builder local v1: frozen
- Administracja strony rebuild strategy: done
- Katalog rebuild plan: done
- Katalog F1 read-only shell: done
- Katalog F2 bounded data map: done
- Katalog local planning layer F3+F4: done (draft state, dry-run, readiness, UI planu zmian)
- Push GicleeApp hygiene: done
- **GicleeApp push workflow:** użytkownik zwykle pushuje lokalną aplikację przyciskiem **„Push GicleeApp do GitHub”** w UI GicleeApp (nie ręcznie przez terminal): `cursor-api` → staging → `eagleblastmusic-lgtm/gicleeapp`; dry-run → audyt → potwierdzenie → commit + push na `main`. Nie dotyczy motywu Shopify, `gicleeart-gpt`, ZIP-a wiedzy ani plików startowych GPT.
- GICLÉE FRAME™ F2 page inventory + RAM editor foundation (v1.40.0): done
- GICLÉE FRAME™ F2.1 page editor workflow (v1.40.1): done
  - multi-variant RAM, type-aware editor, settings/reorder as RAM patches
  - trigger sekcji w nagłówku edytora, popup + drag reorder
  - dry-run, readiness accordion, F1 brand collapsed
- Studio Page Component Editor Pattern: documented (`gicleeframe-planning.md` §7, `admin-components-strategy.md`)
- **Performance Agent** (PA-1A–PA-3B): done lokalnie — guided audit + read-only analysis CLI w `cursor-api/tools/performance_agent/` (testy 162 passed; szczegóły § Performance Agent + GF-P0.1)
- **GF-P0.1** (Details CTA Timing Anchor / Baseline Hygiene): done w kodzie lokalnym; runtime validation pending (wymaga świeżego `--run`)

Not started:
- GICLÉE FRAME™ F3 — lokalny zapis draftów RAM do pliku
- GICLÉE FRAME™ F4 — bounded writer + backup/undo
- F5 / F5.5 preview quality / Shopify sync-deploy
- Katalog writer
- Katalog Shopify integration
- Katalog migration

Next recommended:

**Studio Performance — GICLÉE FRAME 6G.5:** **PASS / checkpoint** (główna nitka zamknięta — nie startować kolejnej szerokiej optymalizacji bez wyraźnego problemu UX po ręcznym teście).

**Osobne ścieżki produktowe (choose one — neither started):**
- **A.** cleanup / runtime hygiene working tree (local M + untracked outside commits)
- **B.** GICLÉE FRAME™ F3 — lokalny zapis draftów RAM (no writer, no Save, no Shopify)

---

## GicleeApp Studio Performance (checkpoint 2026-07-07)

**Kontekst:** optymalizacja wydajności GicleeApp Studio. Fazy **5F–6G.2** i główna nitka **6G.5** (GICLÉE FRAME) przeprowadzone lokalnie w Cursorze (working tree może wyprzedzać GitHub connector).

**Źródło prawdy dla diagnozy:** bundle z **Performance Agent** (`report.md`, `summary.json`) — preferuj nad surowym logiem. Gdy brak bundle: `cursor-api/giclee_app/logs/studio_perf.log`. **Zawsze od metryk, nie od hipotez po UI.**

### Zasada diagnostyki (obowiązkowa)

Jeśli użytkownik pisze „dalej muli”, „wolno się otwiera”, „sekcje przycinają” — GPT **najpierw prosi o**:
1. najnowszy bundle Performance Agent (`report.md` / `summary.json` z `cursor-api/reports/performance/**`), **albo**
2. najnowszy `giclee_app/logs/studio_perf.log`, **albo**
3. raport Cursora z agregacją ostatniej sesji.

**Nie zgadywać po objawie. Najpierw metryki, potem kod.**

Jeśli GitHub connector widzi starszy stan niż lokalny Cursor — **lokalny working tree / log użytkownika wygrywa** dla bieżącej diagnozy wydajności.

### Status faz (done lokalnie) — skrót 5F–6G.2

**5F / 5G — Hub:** batching, hover/auto hydration OFF; hub nie jest głównym bottleneckiem.

**6A–6F:** cold views, GF progressive boot (~2.8 s → ~0.6–0.7 s), progressive `page_context`, lazy divider groups, lightweight setting rows, responsive section selection.

**6G.1–6G.2:** route shell, freeze reduction; po 6G.2 GF `open` ~31 ms, `visible_ready` ~179 ms; Asset Lab shell batches ~13–18 ms.

---

## GicleeApp / GICLÉE FRAME performance checkpoint

Główna nitka performance **6G.5** jest zamknięta jako **PASS / checkpoint**.

### Zrealizowane fazy

- **6G.5-K** — Sections Column Early Lane.
- **6G.5-L** — Split sections column.
- **6G.5-L.1** — Extras layout fix.
- **6G.5-M** — Defer init refresh behind early lane.
- **6G.5-N.DIAG** — Hub mount lane diagnostics.
- **6G.5-N.1** — `GicleeFrameView.uses_async_first_paint=True`, launcher `update_idletasks` skipped.
- **6G.5-O** — repeatable smoke baseline.
- **6G.5-P.DIAG** — `CTkScrollableFrame` constructor identified as sections shell bottleneck.
- **6G.5-Q.SPIKE** — static lane before scroll upgrade.
- **6G.5-Q.1** — scroll upgrade delayed until after perceived ready.
- **6G.5-R.DIAG** — perceived ready gate attribution; control gate identified as last gate.
- **6G.5-S.DIAG** — section click interaction latency diagnostics.
- **6G.5-S.1** — selection stability during `init_refresh.light` + editor identity prewarm.
- **6G.5-S.2A** — editor rows/form shell warmup.
- **6G.5-S.2A.VERIFY** — click UX cause matrix.
- **6G.5-S.2B** — selection priority lane / populate enter queue reduction.

### Najważniejsze wyniki

- Hub → GICLÉE FRAME mount queue improved; launcher `update_idletasks` is skipped for `GicleeFrameView`.
- `early_lane_enter.queue_latency_ms` stable around ~35 ms.
- Static lane shows real first rows early; `first_visible_ready` moved into roughly ~175–250 ms range depending on run.
- `CTkScrollableFrame` cost is shifted to scroll upgrade after first/perceived readiness.
- `ensure_identity` cold cost was removed from first click via identity prewarm.
- `ensure_rows` cold cost was reduced via rows prewarm.
- Section click latency improved significantly in **S.2B**:
  - `click → populate_enter` median around ~17.5 ms,
  - max around ~27.3 ms in verify run,
  - divider `populate_done` around ~55 ms,
  - section_legacy `populate_done` around ~59 ms,
  - media_section `populate_done` around ~56 ms,
  - highlight remains around ~8–18 ms.
- Rapid clicking works; latest generation wins and stale jobs are cancelled/ignored.
- Page context remains a secondary **P2** topic: it can still take roughly ~200–430 ms cumulative, but it is not the main blocker for the immediate click response.
- Perceived ready can still be influenced by control gate / control deferred chain, but this is no longer the primary UX blocker for clicking sections.

### Current recommendation

- **STOP / checkpoint** the main 6G.5 performance thread.
- Do not start another broad optimization unless manual UX still shows a clear problem.
- Optional later topic: page context polish / perceived-ready semantics / control late work, only if user still feels lag after real manual use.
- Optional small hygiene: update analyzer scenario C criteria so immediate basic populate is not incorrectly reported as FAIL.

### Post-checkpoint UX follow-up

6G.5-S.2B remains a technical PASS / checkpoint for the main GICLÉE FRAME performance thread.

However, the user reported after the checkpoint that real manual interaction still does not feel fully ideal when clicking sections. This does not reopen the whole 6G.5 performance track. Future work should be symptom-driven and scoped narrowly.

Next optional follow-up:
- 6G.5-T.UX — Manual Friction Capture
  - run GICLÉE FRAME with `GICLEE_STUDIO_PERF=1`,
  - manually test early click, normal section clicks, rapid section clicks, and visual stability,
  - identify the exact UX symptom before proposing code changes.

Do not start broad optimization without a concrete manual UX symptom and perf log.
Likely future micro-topics, only if confirmed by manual UX:
- page context polish,
- static lane / scroll upgrade flicker polish,
- selection visual stability,
- preview repaint polish,
- early-click race validation.

### GF-P0.1 — instrumentation follow-up (nie reopen 6G.5)

Lokalnie wdrożono **GF-P0.1**: details CTA loguje latencję od request/CTA (`since_request_ms`, `since_details_cta_ms`), nie od wieku widoku (`since_enter_ms`). To wąski follow-up instrumentation — **nie** ponowne otwarcie nitki 6G.5. Pełna walidacja wymaga **świeżego `--run`** (świadomie odłożone). Stare bundle mogą nadal pokazywać legacy wiersze w `slow_events.csv` — to oczekiwane, nie błąd narzędzia.

### Performance guardrails

- GicleeApp Studio performance = lokalny projekt aplikacji (`gicleeapp`), **nie** Shopify theme.
- Nie ruszać `Komponenty/*`, Shopify sync/deploy, writerów, Save/Zapisz/Zastosuj bez osobnej zgody.
- Nie zmieniać launcher lifecycle bez osobnego scope.
- Nie zmieniać static lane / scroll upgrade bez nowej scoped phase.
- Nie zmieniać DnD behavior bez explicit scope.
- Background Builder local v1 pozostaje frozen.
- Cursor aktualizuje tylko źródła w `Pliki startowe dla GPT` — **nie generuje ZIP-a** (ZIP = Okno rozmowy u użytkownika).

Technical backlog (only after separate acceptance):
- Katalog bounded writer / save layer
- zero Shopify / sync / deploy
- zero Save / Zapisz / Zastosuj without explicit approval
- do not mutate Komponenty/* runtime data from Studio panels

Important guardrails:
- Knowledge pack source folder: `C:\Strona\pusty\Pliki startowe dla GPT` — **Cursor edytuje tylko pliki źródłowe `.md` / `.txt` w tym folderze**
- **Cursor NIE generuje ZIP-a wiedzy** — bez osobnego, wyraźnego polecenia użytkownika
- ZIP wiedzy (`giclee_cursor_architect_knowledge_v37.zip`) generuje **automatycznie program użytkownika** przy wysyłce paczki przez **Okno rozmowy** (Integracja z GPT) — nie traktuj ZIP jako źródła prawdy
- Cursor nie uruchamia: `build_starter_knowledge_zip()`, GUI **Skopiuj .zip**, żadnego ręcznego generatora ZIP
- GICLÉE FRAME F2.1: RAM-only — no write_text, no writer, no sync/deploy, no Komponenty/* mutation from panel
- Do not start F3/F4/writer without separate approval
- Do not add Save/Zapisz/Zastosuj without separate approval
- Do not touch Shopify/sync/deploy
- Katalog F2 remains read-only
- tldobio absorbed into Katalog
- Background Builder local v1 = Level 2 reference (frozen)

Reference docs (repo):
- `cursor-api/giclee_app/docs/gicleeframe-planning.md`
- `cursor-api/giclee_app/docs/admin-components-strategy.md` (Giclee Frame = pattern reference)

---

## Performance Agent + GF-P0.1 (checkpoint PA/GF — 2026-07-08)

**Status:** PA-1A…PA-3B **done lokalnie**. GF-P0.1 **done w kodzie**, **bez świeżej walidacji runtime**.  
**Testy:** 162 passed (pakiet PA + powiązane studio perf).  
**Commit / push / ZIP:** brak w tym checkpointcie — nie zakładać bez potwierdzenia użytkownika.

**Lokalizacja:** `cursor-api/tools/performance_agent/` (narzędzie diagnostyczne; nie mieszać z optymalizacją runtime Studio 6G.5).  
**Canonical docs:** `tools/performance_agent/README.md` (GitHub) = `cursor-api/tools/performance_agent/README.md` (local). Run from `cursor-api/`.

### Mapa faz (done)

| Faza | Zakres | Status |
|------|--------|--------|
| PA-1A–PA-1C.2 | parse-only, wizard, `--run`, coverage, human-readable scenarios | done |
| PA-1D | `--latest`, `--list-reports` (read-only index) | done |
| PA-1E–PA-1H | ChatGPT copy, health gate | done |
| PA-1I | `--doctor`, `--prepare-chatgpt-latest`, `--open-latest` | done |
| PA-2A | `--analyze-*`, `--compare-*` | done |
| PA-2B | `--hotspots-*`, `--timeline-*`, `--cursor-prompt-*` | done |
| PA-2C | `--history`, `--trend-latest`, `--baseline-candidate` | done |
| PA-3A | `--coverage-*`, `--run-playbook`, `--scenario-checklist` | done |
| PA-3B | semantics (`since_enter_ms` filter, evidence tiers) | done |
| GF-P0.1 | details CTA: `since_request_ms` / `since_details_cta_ms` | done locally; fresh run pending |

### Operator CLI — read-only analysis (preferowane w sesji)

```powershell
python -m tools.performance_agent --doctor
python -m tools.performance_agent --prepare-chatgpt-latest
python -m tools.performance_agent --analyze-latest
python -m tools.performance_agent --compare-latest
python -m tools.performance_agent --hotspots-latest
python -m tools.performance_agent --timeline-latest
python -m tools.performance_agent --cursor-prompt-latest
python -m tools.performance_agent --history
python -m tools.performance_agent --trend-latest
python -m tools.performance_agent --baseline-candidate
python -m tools.performance_agent --coverage-latest
python -m tools.performance_agent --run-playbook
python -m tools.performance_agent --scenario-checklist
```

**Generowanie nowego bundle** (gdy potrzebny świeży run): `--parse-only` · `--manual` · `--run`.

**Rekomendowany flow:** `--doctor` → `--coverage-latest` / `--analyze-latest` → `--hotspots-latest` / `--timeline-latest` → `--cursor-prompt-latest`.

### Zasady interpretacji (nie traktować jako bug)

| Sygnał | Znaczenie |
|--------|-----------|
| `1/9` coverage | **Weak evidence** — nie dowód poprawy/regresji wydajności |
| `9/9` + `early_event_seen` | **Reviewable / READY** z caveat (np. `dashboard_cold`) — nie alarm jak 1/9 |
| `since_enter_ms` | Wiek widoku — **nie** latencja kliknięcia |
| details CTA | Prawdziwe pola: **`since_request_ms`**, **`since_details_cta_ms`** (GF-P0.1) |
| Stary `slow_events.csv` | Legacy wiersze (`since_click_ms`, `cancelled`) w starych bundle — **oczekiwane** przy `--hotspots-latest` |
| `SCENARIO_LOG_NOT_CONFIRMED` | Jakość danych sesji — **nie** automatycznie regresja runtime |

### Baseline bundles (GF)

- **Dobry pierwszy GF baseline:** `20260707-214246_giclee_studio`
- **Nie używać jako GF baseline:** `20260707-160215_giclee_studio` — nie mierzył `studio.gicleeframe.*`
- Automatyczny wybór: `--baseline-candidate`; ręczne porównanie: `--compare-reports`

### Pending

1. **Świeży `--run`** — walidacja GF-P0.1 w nowym `slow_events.csv` / timeline (świadomie odłożone)
2. **Opcjonalny P1** — `render_section_list` / selection pipeline — **tylko** jeśli potwierdzi świeży baseline; nie startować bez dowodu

### Bundle wyjściowy

`reports/performance/<YYYYMMDD-HHMMSS>_giclee_studio/` — m.in. `report.md`, `summary.json`, `slow_events.csv`, `scenario_timeline.csv`, `raw/studio_perf.log`. Runtime output i log ignorowane przez git.
